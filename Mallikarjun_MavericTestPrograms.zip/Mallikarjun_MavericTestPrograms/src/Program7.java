import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

//Write a program to remove duplicate values from the has set that has the key value pair as below 

/*Key 1: TestVal1 
Key 2: TestVal2 
Key 3: TestVal1 
Key 4: TestVal2 
Key 5: TestVal2 
Key 6: TestVal3*/

public class Program7 {

	public static void main(String[] argv) {
	      ArrayList<Integer>Key1 = new ArrayList<Integer>();
	      Key1.add(100);
	      Key1.add(200);
	      Key1.add(100);
	      Key1.add(200);
	      Key1.add(200);
	      Key1.add(300);
	           
	      HashSet<Integer>set = new HashSet<Integer>(Key1);
	      List<Integer>list2 = new ArrayList<Integer>(set);
	      System.out.println("List after removing duplicate elements:");
	      for (Object ob: list2)
	         System.out.println(ob);
	   }
}


/* Output:
List after removing duplicate elements:
100
200
300*/