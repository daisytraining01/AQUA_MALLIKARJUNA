/*Write a program to compare two strings using JAVA Program  */

public class Program5 {

	public static void main(String[] args) {
		
		String a = "Maks";
		String b = "MAKS";
		if(a.equals(b)) {
			System.out.println("Both Strings are equl");
		}
		else {
			System.out.println("Both Strings are not equal");
		}
		if(a.equalsIgnoreCase(b)) {
			System.out.println("Both Strings are equal");
		}
		else {
			System.out.println("Both strings are equal");
		}

	}

}

/*Output:
Both Strings are not equal
Both Strings are equal

for the following values:
String a = "Maks";
String b = "MAKS";*/
	
